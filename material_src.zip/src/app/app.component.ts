import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  isChecked = false;
  colors=[
    {id:1,name:'blue'}, {id:2,name:'red'}, {id:2,name:'green'},
  ]



  onChange($event){
    console.log($event);
  }
}
